package com.dlx.employees.modele;

import com.dlx.employee.modele.bean.Salariee;

public class DAO {
	Salariee sals[]= {
	new Salariee(1, "Dupont","Paul",36,2000),
	new Salariee( 2,"Martin","Sophie",36,2000),
	new Salariee(3, "Duval","Paul",36,2000),
	new Salariee( 4,"Duval","Alfred",36,2000),
	new Salariee(5, "Martin","Patricia",36,2000),
	new Salariee( 6,"Dupont","Sophie",36,2000),
	
	};
	EntrepriseDao ge= new EntrepriseDao("GE",sals);
	
	

}
