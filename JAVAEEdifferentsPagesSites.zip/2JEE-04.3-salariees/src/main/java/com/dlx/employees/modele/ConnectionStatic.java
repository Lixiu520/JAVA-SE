package com.dlx.employees.modele;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionStatic {

		private static Connection cn;
		public static Connection connecter() throws SQLException {
			if (cn==null) {
				cn = DriverManager.getConnection(
		"jdbc:mysql://localhost:8889/coursJava?serverTimezone=UTC", "root", "root") ;
				System.out.println("je ne sais pas????");
			}
			System.out.println("je ne sais pas");
			return cn;
		}

}
