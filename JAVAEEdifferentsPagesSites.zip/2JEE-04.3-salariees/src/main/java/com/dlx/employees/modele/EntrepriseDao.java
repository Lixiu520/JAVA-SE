package com.dlx.employees.modele;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.dlx.employee.modele.bean.Salariee;


public class EntrepriseDao {
	private String nom;
	private ArrayList<Salariee> salariees=new ArrayList<>();
	private Salariee salariee;
	
	public EntrepriseDao(String nom) {
		super();
		this.nom = nom;
		
		 
	}
	
	public EntrepriseDao(String nom, Salariee sals[]) {
		super();
		this.nom = nom;
		for(Salariee sl:sals) {
			salariees.add(sl);
		}
		
		 
	}


public ArrayList<Salariee> obtenirSalariee() {
	
		// TODO Auto-generated method stub
		String sql =  "select * from `salaries`" ;

		Statement smt;
		try {
			smt = ConnectionStatic.connecter().createStatement();
		
		ResultSet rs = smt.executeQuery(sql) ; // exécution commande
		//System.out.println("ID\t NOM\t PRENOM \tSALAIRE") ;

		while (rs.next()) {	// boucle dans la BD, affichage d'un champ
			salariee= new Salariee(rs.getInt("id"),rs.getString("nom"),rs.getString("prenom"),rs.getInt("salaire"),rs.getInt("age"));
			System.out.println(salariee);
			salariees.add(salariee);
			//System.out.println(rs.getString("id")+"\t"+rs.getString("last_name")+"\t "+rs.getString("first_name")+"\t\t "+rs.getInt("salaire")) ;
		}
		rs.close();

		smt.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.err.println(e1);
		} // création statement
		return salariees;
	
}


	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public ArrayList<Salariee> getSalariees() {
		return salariees;
	}
	public void setSalariees(ArrayList<Salariee> salariees) {
		this.salariees = salariees;
	}
	
	@Override
public String toString() {
	return "EntrepriseDao [nom=" + nom + ", salariees=" + salariees + ", salariee=" + salariee + "]";
}
	

}
