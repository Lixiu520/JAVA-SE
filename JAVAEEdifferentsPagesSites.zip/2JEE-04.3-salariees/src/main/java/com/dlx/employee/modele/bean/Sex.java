package com.dlx.employee.modele.bean;

public enum Sex {
	HOMME,
	FEMME

}
