package com.dlx.employee.controleur;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlx.employee.modele.bean.Salariee;
//import com.dlx.employees.modele.EntrepriseDao;
import com.dlx.employees.modele.EntrepriseDao;

/**
 * Servlet implementation class SalarieeControleur
 */
@WebServlet("/SalarieeControleur")
public class SalarieeControleur extends HttpServlet {
	//private String vue="/WEB-INF/SalarieesVue.jsp";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalarieeControleur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		 
//		Salariee sals[]= {
//				new Salariee(1, "Dupont","Paul",36,2000),
//				new Salariee( 2,"Martin","Sophie",36,2000),
//				new Salariee(3, "Duval","Paul",36,2000),
//				new Salariee( 4,"Duval","Alfred",36,2000),
//				new Salariee(5, "Martin","Patricia",36,2000),
//				new Salariee( 6,"Dupont","Sophie",36,2000),
//				
//				};
				EntrepriseDao ge= new EntrepriseDao("GE");
//		
		ge.obtenirSalariee();
//				for(Salariee sa:ge.getSalariees()) {
//					ge.getSalariees().add(sa);
//				}
		request.setAttribute("Entreprise", ge.getSalariees());
//				request.setAttribute("salariees", sals);
//				System.out.println(sals);//pour tester
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		this.getServletContext().getRequestDispatcher("/WEB-INF/SalarieesVue.jsp").forward( request, response );
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
