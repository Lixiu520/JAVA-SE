package com.dlx.employee.modele.bean;

import java.util.ArrayList;

public class Entreprise {
	private String nom;
	private ArrayList<Salariee> salariees=new ArrayList<>();
	public Entreprise(String nom, Salariee sls[]) {
		super();
		this.nom = nom;
		for(Salariee sl:sls) {
			this.salariees.add(sl);
		}
		 
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public ArrayList<Salariee> getSalariees() {
		return salariees;
	}
	public void setSalariees(ArrayList<Salariee> salariees) {
		this.salariees = salariees;
	}
	public Entreprise(String nom, ArrayList<Salariee> salariees) {
		super();
		this.nom = nom;
		this.salariees = salariees;
	}
	
	

}
