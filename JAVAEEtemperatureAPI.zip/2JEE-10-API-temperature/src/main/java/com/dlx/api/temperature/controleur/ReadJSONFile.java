package com.dlx.api.temperature.controleur;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Servlet implementation class ReadJSONFile
 */
@WebServlet("/ReadJSONFile")
public class ReadJSONFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String urlJSon="/WEB-INF/ReadJSON.jsp";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReadJSONFile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		JSONParser pareser= new JSONParser();
		JSONParser pareser1= new JSONParser();
		Reader test= new FileReader("/Users/audreydai/eclipse-workspace/2JEE-10-API-temperature/src/main/webapp/Test.json");
		System.out.println(test);
		Reader test2 = new FileReader("/Users/audreydai/eclipse-workspace/2JEE-10-API-temperature/src/main/webapp/Test2.json");
		try {
		Object jsonObj = pareser.parse(test);
			Object jsonObj1 = pareser1.parse(test2);
			System.out.println(jsonObj);
			System.out.println(jsonObj1);
			JSONObject jsonObject = (JSONObject) jsonObj;
//			JSONObject jsonObject1 = (JSONObject) jsonObj1;
			JSONArray jsonArray= (JSONArray) jsonObj1;
			System.out.println(jsonObject);
//			System.out.println(jsonObject1);
			 String name = (String) ((HashMap) jsonArray.get(1)).get("name");
			System.out.println("name = " + name);	
			 String titre = (String) ((HashMap) jsonArray.get(0)).get("title");
			System.out.println("Titre = " + titre);	
		
			request.setAttribute("name", name);
			request.setAttribute("titre", titre);
			URL url = new URL("https://api.openweathermap.org/data/2.5/weather?q=Toulouse&appid=4457cf854fb04990852e85c518e0a650");
			URLConnection uc = url.openConnection();
			InputStream in = uc.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			System.out.println(reader);
			Object temperature = pareser1.parse(reader);
			System.out.println(temperature);
			JSONObject temperature1 = (JSONObject) temperature;
			 Object tprt = temperature1.get("main");
			String ville =     (String) temperature1.get("name");
			System.out.println(tprt);
			System.out.println(ville);
			double tp=(double) ((HashMap) tprt).get("temp");
			request.setAttribute("ville", ville);
			request.setAttribute("temperature", tp);
			System.out.println(tp);
//			JSONObject tprt = (JSONObject) ((HashMap) temperature).get("main");
//			System.out.println(tprt);
//			JSONObject tp=(JSONObject)tprt.get("temp");
//			System.out.println(tp);
//			String tp= (String)  tprt.get("temp");
//			System.out.println(tp);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	this.getServletContext().getRequestDispatcher(urlJSon).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
