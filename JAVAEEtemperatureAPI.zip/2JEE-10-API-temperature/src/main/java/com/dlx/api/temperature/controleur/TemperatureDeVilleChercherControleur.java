package com.dlx.api.temperature.controleur;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Servlet implementation class TemperatureDeVilleChercherControleur
 */
@WebServlet("/TemperatureDeVilleChercherControleur")
public class TemperatureDeVilleChercherControleur extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String urlVue="/WEB-INF/TemperatureDeMaVielleVue.jsp";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TemperatureDeVilleChercherControleur() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		

		this.getServletContext().getRequestDispatcher(urlVue).forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			JSONParser pareser1= new JSONParser();
			String ville= request.getParameter("ville");
			URL url = new URL("https://api.openweathermap.org/data/2.5/weather?q="+ville+"&appid=4457cf854fb04990852e85c518e0a650");
			request.setAttribute("ville", ville);
			URLConnection uc = url.openConnection();
			InputStream in = uc.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			System.out.println(reader);
			Object temperature;
			temperature = pareser1.parse(reader);
			System.out.println(temperature);
			JSONObject temperature1 = (JSONObject) temperature;
			HashMap tprt = (HashMap) temperature1.get("main");
			HashMap pays = (HashMap) temperature1.get("sys");
			String paysChercher=(String) pays.get("country");
			System.out.println(tprt);
			System.out.println(ville);
			double tp=Math.round((double) ( tprt).get("temp")-273.15);
			String degre="°C";
			request.setAttribute("degre", degre);
			request.setAttribute("pays", paysChercher);
			request.setAttribute("temperature", tp);
			System.out.println(tp);
			
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			request.setAttribute("Erreur", e.getMessage());
			urlVue="/WEB-INF/ErreurVue.jsp";
		}
		doGet(request, response);
	}

}
