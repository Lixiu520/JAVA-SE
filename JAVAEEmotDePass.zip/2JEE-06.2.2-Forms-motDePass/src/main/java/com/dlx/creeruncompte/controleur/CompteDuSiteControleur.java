package com.dlx.creeruncompte.controleur;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlx.comptedusite.modele.CompteDuSite;
import com.dlx.comptedusite.modele.bean.Compte;
import com.dlx.comptedusite.modele.exception.CompteException;

/**
 * Servlet implementation class CompteDuSiteControleur
 */
@WebServlet("/CompteDuSite")
public class CompteDuSiteControleur extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String url="/WEB-INF/CompteDuSiteVue.jsp";
	private String targetUrl="/WEB-INF/ResultatInscription.jsp";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompteDuSiteControleur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		Date date=new Date(123, 4, 26);
//		Compte compte=new Compte("sag",date,"daor");
//		System.out.println(compte);
//		CompteDuSite cds1=new CompteDuSite();
//		cds1.setCompte(compte);
//		System.out.println(cds1);
		this.getServletContext().getRequestDispatcher(url).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		CompteDuSite cds=new CompteDuSite(request);	
			request.setAttribute("Compte", cds.getCompte());
			
			System.out.println(cds.getCompte());
			System.out.println(cds.getErreur());
			System.out.println(cds.getCompte().getDateDeNaissance());
			
		
		if(cds.getErreur().isEmpty()) {
			
			this.getServletContext().getRequestDispatcher(targetUrl).forward(request, response);
		}else {
			request.setAttribute("Erreur",cds.getErreur());
			doGet(request, response);
		}
		
	}

}
