package com.dlx.comptedusite.modele.bean;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Compte {
	//La grille de création de compte comporte: 
	//un identifiant, une date de naissance,
	//un mot de passe, un mot de passe bis)
	private String identifiant;
	private Date dateDeNaissance;
	private SimpleDateFormat sdf;
	private String motDePass;
	public Compte(String identifiant, Date dateDeNaissance, String motDePass) {
		super();
		this.identifiant = identifiant;
		
		this.dateDeNaissance =  dateDeNaissance;
		this.motDePass = motDePass;
	}
	public Compte() {
		super();
	}
	
	
	public String getIdentifiant() {
		return identifiant;
	}
	public void setIdentifiant(String identifiant) {
		this.identifiant = identifiant;
	}
	public Date getDateDeNaissance() {
		return dateDeNaissance;
	}
	public void setDateDeNaissance(Date dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}
	public String getMotDePass() {
		return motDePass;
	}
	public void setMotDePass(String motDePass) {
		this.motDePass = motDePass;
	}
	@Override
	public String toString() {
		return "CompteModele [identifiant=" + identifiant + ", dateDeNaissance=" + dateDeNaissance + ", motDePass="
				+ motDePass + "]";
	}
	
	

}
