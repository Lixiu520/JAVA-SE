package com.dlx.comptedusite.modele;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import com.dlx.comptedusite.modele.bean.Compte;
import com.dlx.comptedusite.modele.exception.CompteException;


public class CompteDuSite {
	private Compte compte;
	private Map<String, String> erreur= new HashMap<>();
	private String message;
	private Date  dateDeNaissance;
	private String mdpDouble;

	public CompteDuSite(HttpServletRequest request) {
		super();
		this.transformer(
				request.getParameter("identifiant"),
				request.getParameter("DateDeNaissance"),
				request.getParameter("motDePass"),
				request.getParameter("mdpDouble")
				) ;
		compte = new Compte(
				request.getParameter("identifiant"),
				dateDeNaissance,
				request.getParameter("motDePass"));	
		this.erreur = erreur;
		this.message = message;
		
	}
	public CompteDuSite(Compte compte) {
		super();
		this.compte = compte;
	}
	public void transformer(String identifiant, String  date, String motDePass, String mdpDouble ) {
		
		
		
//		Pattern pattern = Pattern.compile("^BGE-[0-9]{3,3}$", Pattern.CASE_INSENSITIVE);
		
//		Matcher matcher= pattern.matcher("^BGE-[0-9]{3,3}$");
//		boolean matchFound = matcher.find();
		if(!identifiant.matches("^BGE-[0-9]{3,3}$")) {
			String message="Attention au format de identifiant: trois lettre au debut, tiret , puis trois chiffres";
			erreur.put("identifiant", message);
//			throw new CompteException(message);
		}
		
		if(motDePass.length()<6) {
			String message="Attention, le mot de pass doit etre plus de 6 caracteres!";
			erreur.put("mdp", message);
		//	throw new CompteException(message);
		}
	
		if (mdpDouble!=null&&!mdpDouble.equals(motDePass) ) {
			String message="Attention, les deux saisie ne sont pas identifques!";
			erreur.put("mdpDouble", message);
			//throw new CompteException(message);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			 dateDeNaissance =  sdf.parse(date); 
			
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				String message="Attention au format de date! "+e.getMessage();
				erreur.put("date1", message);
			//	throw new CompteException(message);
			}	
		
	}
	public Compte getCompte() {
		return compte;
	}
	public void setCompte(Compte compte) {
		this.compte = compte;
	}
	
	public Map<String, String> getErreur() {
		return erreur;
	}
	public void setErreur(Map<String, String> erreur) {
		this.erreur = erreur;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public CompteDuSite() {
		// TODO Auto-generated constructor stub
	}
	public Date getDateDeNaissance() {
		return dateDeNaissance;
	}
	public void setDateDeNaissance(Date dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}
	@Override
	public String toString() {
		return "CompteDuSite [compte=" + compte + ", erreur=" + erreur + ", message=" + message + ", dateDeNaissance="
				+ dateDeNaissance + "]";
	}
	

}
