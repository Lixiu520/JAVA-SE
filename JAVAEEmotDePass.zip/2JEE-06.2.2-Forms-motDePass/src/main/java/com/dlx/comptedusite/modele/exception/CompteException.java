package com.dlx.comptedusite.modele.exception;

public class CompteException extends Exception {

	private static final long serialVersionUID = 1L;
	private String message;
	public CompteException(String message) {
		super();
		this.message = message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "CompteException [message=" + message + "]";
	}
	

}
